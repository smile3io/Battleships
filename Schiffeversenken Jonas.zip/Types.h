#pragma once

enum class Render {
    SHIPS, SHOTS, ALL       // render 
};

enum class UI {
    PLACE, SHOOT, MULTI    // decides which UI 
};